# mdl rules can be referenced as follows:
#
# https://github.com/mivok/markdownlint/blob/master/docs/RULES.md

all
rule 'MD029', :style => :ordered
exclude_rule 'MD032'
exclude_rule 'MD013'